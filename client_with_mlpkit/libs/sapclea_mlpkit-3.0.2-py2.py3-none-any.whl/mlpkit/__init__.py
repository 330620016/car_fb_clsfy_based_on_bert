import sys
import os
import logging
from .exceptions import ModelError, CacheError, ServiceBrokerError
from .vcap_services_util import get_deployment_api_base_url, get_model_api_base_url
from .constants import (
    VCAP_SERVICES,
    MLP_FOUNDATION_SERVICE_NAME,
    MLP_FOUNDATION_SERVICE_INSTANCE_NAME,
    MLP_DEPLOYMENT_API_BASE_URL,
    MLP_MODEL_API_BASE_URL,
    MLP_MODEL_VALID_DURATION,
    HEADER_X_CORRELATION_ID
)

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))


def _setup_env_vars():
    def _warn_for_var(env_var, default_val=None):
        if env_var not in os.environ:
            LOG.warning('Environment variable %s is not set!', env_var)
            if default_val:
                LOG.info('Using default value for %s=%s', env_var, default_val)

    if not os.getenv(MLP_MODEL_API_BASE_URL):
        model_api_base_url = get_model_api_base_url()
        if model_api_base_url:
            os.environ[MLP_MODEL_API_BASE_URL] = model_api_base_url

    if not os.getenv(MLP_DEPLOYMENT_API_BASE_URL):
        deployment_api_base_url = get_deployment_api_base_url()
        if deployment_api_base_url:
            os.environ[MLP_DEPLOYMENT_API_BASE_URL] = deployment_api_base_url

    _warn_for_var(MLP_DEPLOYMENT_API_BASE_URL)
    _warn_for_var(MLP_MODEL_API_BASE_URL)
    _warn_for_var(MLP_MODEL_VALID_DURATION, 3600)

_setup_env_vars()
