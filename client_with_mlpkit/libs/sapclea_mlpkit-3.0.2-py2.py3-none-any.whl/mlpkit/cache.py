"""Provides cache utility functions.
"""
# pylint: disable=W0603
import os
import sys
import logging
import json
import time
import math
import threading
from collections import OrderedDict

try:
    import resource

    IS_UNIX = True
except ImportError:
    IS_UNIX = False
import tempfile
import redis
from mlpkit import CacheError
from pympler.asizeof import Asizer

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))

HANLDE_LARGE_OBJECT = False
LEVEL_1_IN_MEMORY = 1
LEVEL_2_REDIS = 2
REDIS_KEY_PREFIX = 'cache:mlp:'


def validate_cache_level(cache_level):
    """Validate cache_level.

    :param cache_level: Value represents cache level.

    :return: True if cache_level is supported, False otherwise.
    """
    return cache_level in (LEVEL_1_IN_MEMORY, LEVEL_2_REDIS)


LEVEL_1_IN_MEMORY_CACHE_LIMIT = None
IN_MEMORY_LARGE_OBJECT_SIZE = None
REDIS_OBJECT_PARTITION_SIZE = None


def reset_constants():
    """Reset constants to environment variables or defaults."""

    def _check_env_var(_key, _val):
        if _key not in os.environ:
            LOG.warning('''Environment variable %s is not set!
                        Using %s as default...''', _key, str(_val))

    global LEVEL_1_IN_MEMORY_CACHE_LIMIT
    key = 'LEVEL_1_IN_MEMORY_CACHE_LIMIT'
    val = 512 * 1024 * 1024
    _check_env_var(key, val)
    LEVEL_1_IN_MEMORY_CACHE_LIMIT = max(0, int(os.getenv(key, default=val)))

    global IN_MEMORY_LARGE_OBJECT_SIZE
    key = 'IN_MEMORY_LARGE_OBJECT_SIZE'
    val = 0
    _check_env_var(key, val)
    IN_MEMORY_LARGE_OBJECT_SIZE = max(0, int(os.getenv(key, default=val)))

    global REDIS_OBJECT_PARTITION_SIZE
    key = 'REDIS_OBJECT_PARTITION_SIZE'
    val = 500 * 1000 * 1000
    _check_env_var(key, val)
    REDIS_OBJECT_PARTITION_SIZE = max(0, int(os.getenv(key, default=val)))

    global HANLDE_LARGE_OBJECT
    HANLDE_LARGE_OBJECT = bool(IN_MEMORY_LARGE_OBJECT_SIZE)


reset_constants()

"""
{'object_key': 
[object_, validate_time, size, version_id]}
"""
OBJECT_, VALIDATE_TIME, SIZE, VERSION_ID = 0, 1, 2, 3
__objects__ = OrderedDict()
LOCK = threading.Lock()
_total_cache_size = 0

__large_object_keys__ = []
"""
list of objects that exceed IN_MEMORY_LARGE_OBJECT_SIZE
"""


def _bytes_to_str(obj):
    if isinstance(obj, str):
        pass
    elif isinstance(obj, bytes):
        obj = obj.decode()
    else:
        raise TypeError('Neither str nor bytes was found.')
    return obj


def _meta_object_key(object_key):  # pragma: no cover
    return object_key + ':meta'


def _redis_object_key(object_key):  # pragma: no cover
    return REDIS_KEY_PREFIX + object_key


def _object_partition_key(object_key, partition):  # pragma: no cover
    return object_key + str(partition)


def _delete_large_objects_in_memory():
    for k in __large_object_keys__:
        del __objects__[k]
    del __large_object_keys__[:]


def _flush_memory():
    """
    Force to clear in-memory cache.
    Not thread-safe; not to be used by external program.
    """
    LOG.info('Flushing in-memory cache...')
    global _total_cache_size
    _total_cache_size = 0
    __objects__.clear()
    del __large_object_keys__[:]


def _get_object_in_memory(object_key, version_id=None, validate=None):
    LOG.info('Retrieving object from in-memory cache...')

    # not retrieving the large object, del large object
    if HANLDE_LARGE_OBJECT and object_key and __large_object_keys__ and object_key not in __large_object_keys__:
        LOG.debug('object_key is not for large object: %s.\nDeleting large object(s) from cache...',
                  object_key)
        _delete_large_objects_in_memory()

    # object not in cache dict
    if object_key not in __objects__:
        LOG.debug('object_key not found in cache: %s', object_key)
        return None

    # object version in cache mismatches querying object version
    if version_id:
        cached_v = __objects__[object_key][VERSION_ID]
        if version_id != cached_v:
            LOG.debug('version_id: %s mismatches cached version_id: %s.\nDeleting object: %s',
                      version_id, cached_v, object_key)
            del __objects__[object_key]
            return None

    if validate:
        obj_list = __objects__[object_key]
        cached_validate_time = obj_list[VALIDATE_TIME]
        cached_version_id = obj_list[VERSION_ID]
        valid, v_time = validate(cached_version_id, cached_validate_time)
        if valid:
            LOG.info('Cached object is still valid. Updating validate_time...')
            obj_list[VALIDATE_TIME] = v_time
        else:
            LOG.info('Cached object is not valid. Deleting object: %s from cache...', object_key)
            del __objects__[object_key]
            return None

    __objects__.move_to_end(object_key, last=False)
    LOG.debug('Returning cached object %s from memory with version id: %s',
              object_key, __objects__[object_key][VERSION_ID])
    return __objects__[object_key][OBJECT_]


def _set_object_file_in_memory(object_key, object_file, version_id, deserialize):
    LOG.info('Saving object_file to in-memory cache...')

    if deserialize is None:
        raise TypeError("deserialize cannot be None: Need to deserialize object from object_file.")
    with LOCK:
        maxrss_before = getattr(resource.getrusage(resource.RUSAGE_SELF), 'ru_maxrss') if IS_UNIX else 0
        LOG.debug('Max. Resident Set Size before deserialization: %s', maxrss_before)
        LOG.info('Deserializing object_file...')
        with open(object_file.name, 'rb') as obj_f:
            object_ = deserialize(obj_f)
        maxrss_after = getattr(resource.getrusage(resource.RUSAGE_SELF), 'ru_maxrss') if IS_UNIX else 0
        LOG.debug('Max. Resident Set Size after deserialization: %s', maxrss_after)

        _set_object_in_memory(object_key, object_, version_id, maxrss_after - maxrss_before)
        return object_


def _set_object_in_memory(object_key, object_, version_id, maxrss_delta):
    LOG.info('Saving object_ to in-memory cache...')

    LOG.debug('object_ caused Max. Resident Set Size increased by %s', maxrss_delta)
    asize = Asizer().asizeof(object_, code=True)
    LOG.debug('object_ size measured by pympler: %s', asize)
    size = max(maxrss_delta, asize)
    try:
        size_incr = size - __objects__[object_key][SIZE]
    except KeyError:
        size_incr = size
    curr_t = time.time()
    __objects__[object_key] = [object_, curr_t, size, version_id]
    __objects__.move_to_end(object_key, last=False)
    LOG.debug('size: %s | version_id: %s | validate_time: %s',
              size, version_id, curr_t)
    global _total_cache_size
    _total_cache_size += size_incr

    if HANLDE_LARGE_OBJECT and size > IN_MEMORY_LARGE_OBJECT_SIZE:
        LOG.debug('object: %s is a large object with size: %s\nSaving as large object key...',
                  object_key, size)
        __large_object_keys__.append(object_key)

    if _total_cache_size > LEVEL_1_IN_MEMORY_CACHE_LIMIT:

        LOG.debug('cache size: %s exceeds LEVEL_1_IN_MEMORY_CACHE_LIMIT.', _total_cache_size)
        LOG.info('Deleting LRU object(s)...')
        while True:
            _, lru_val = __objects__.popitem()
            lru_size = lru_val[SIZE]
            assert lru_size >= 0
            _total_cache_size -= lru_size
            if _total_cache_size < LEVEL_1_IN_MEMORY_CACHE_LIMIT:
                break


def _parse_redis_env():
    LOG.info('Parsing redis info...')

    if 'VCAP_SERVICES' in os.environ:
        # cf environment
        services = json.loads(os.getenv('VCAP_SERVICES'))
        redis_credentials = services['redis'][0]['credentials']
        password = str(redis_credentials['password'])
        if 'redis_nodes' in redis_credentials:
            # paid redis service
            redis_info = redis_credentials['redis_nodes'][0]
        else:
            # free redis service
            redis_info = redis_credentials
        redis_env = dict(host=redis_info.get('hostname') or redis_info.get('host'),
                         port=int(redis_info['port']),
                         password=password)
    else:
        # for local development
        redis_env = dict(host=os.getenv('REDIS_HOST', 'localhost'),
                         port=os.getenv('REDIS_PORT', 6379),
                         password=os.getenv('REDIS_PASSWORD', ''))

    return redis_env


def _connect_to_redis():  # pragma: no cover
    redis_env = _parse_redis_env()
    LOG.info('Connecting to redis...')
    redis_client = redis.StrictRedis(**redis_env)
    redis_client.config_set('save', '')
    redis_client.config_set('maxmemory-policy', 'allkeys-lru')

    return redis_client


def _set_object_meta_info_in_redis(redis_client, meta_object_key, meta_info):
    LOG.info('Setting object meta_info in redis...')
    meta_info_str = json.dumps(meta_info)
    redis_client.set(meta_object_key, meta_info_str)


def _deserialize_object_from_redis(redis_client, deserialize, redis_object_key, n_partitions):
    LOG.info('Deserializing object from redis...')

    if deserialize is None:
        raise CacheError("deserialize cannot be None: Need to deserialize object from Redis.")

    if (not isinstance(n_partitions, int)) or n_partitions < 1:
        raise CacheError("Invalid partition number in redis: %s", n_partitions)

    if n_partitions > 1:
        blob = redis_client.get(_object_partition_key(redis_object_key, 0))
        for i in range(1, n_partitions):
            blob += redis_client.get(_object_partition_key(redis_object_key, i))
    else:
        blob = redis_client.get(redis_object_key)

    if not blob:
        return None

    LOG.info('Writing redis data into temp file...')
    with open(tempfile.NamedTemporaryFile('w+b', 256, delete=False).name, 'wb') as temp_f:
        temp_f.write(blob)
    LOG.info('Deserializing temp file into object...')
    with open(temp_f.name, 'rb') as temp_f:
        object_ = deserialize(temp_f)
    os.remove(temp_f.name)
    return object_


def _delete_object_in_redis(redis_client, redis_object_key, redis_meta_object_key, n_partitions):
    LOG.info('Deleting object in redis...')

    if (not isinstance(n_partitions, int)) or n_partitions < 1:
        raise CacheError("Invalid partition number in redis: {}".format(n_partitions))

    names = [redis_meta_object_key]

    if n_partitions > 1:
        for i in range(n_partitions):
            partition_key = _object_partition_key(redis_object_key, i)
            names.append(partition_key)
    else:
        names.append(redis_object_key)

    redis_client.delete(*names)


def _get_object_in_redis(redis_client, deserialize, object_key,
                         version_id=None,
                         validate=None):
    LOG.info('Retrieving object from redis...')

    object_key = _redis_object_key(object_key)
    meta_object_key = _meta_object_key(object_key)
    meta_info = None
    if redis_client.exists(meta_object_key):
        meta_info = json.loads(_bytes_to_str(redis_client.get(meta_object_key)))

    if not isinstance(meta_info, dict):
        return None

    if validate:
        cached_validate_time = meta_info['validate_time']
        cached_version_id = meta_info['version_id']
        valid, v_time = validate(cached_version_id, cached_validate_time)
        if valid:
            if v_time > cached_validate_time:
                LOG.info('Updating validate_time in redis...')
                meta_info['validate_time'] = v_time
                _set_object_meta_info_in_redis(redis_client, meta_object_key, meta_info)
        else:
            LOG.debug('Cached object: %s is not valid.', object_key)
            _delete_object_in_redis(redis_client, object_key, meta_object_key,
                                    int(meta_info['n_partitions']))
            return None

    return _deserialize_object_from_redis(
        redis_client, deserialize, object_key, int(meta_info['n_partitions'])) if \
        (version_id is None or version_id == meta_info['version_id']) else None


def _set_object_file_in_redis(redis_client, object_key, object_file, version_id):
    LOG.info('Saving object file to redis...')

    object_key = _redis_object_key(object_key)
    meta_object_key = _meta_object_key(object_key)
    if redis_client.exists(meta_object_key):
        meta_info = json.loads(_bytes_to_str(redis_client.get(meta_object_key)))
        if isinstance(meta_info, dict) and version_id == meta_info['version_id']:
            return

    with open(object_file.name, 'rb') as obj_f:
        blob = obj_f.read()
    n_partitions = 1
    size = Asizer().asizeof(blob)
    if size > REDIS_OBJECT_PARTITION_SIZE:
        n_partitions = int(
            math.ceil(float(size) / REDIS_OBJECT_PARTITION_SIZE))

    _set_object_meta_info_in_redis(redis_client,
                                   meta_object_key,
                                   {'version_id': version_id,
                                    'n_partitions': n_partitions,
                                    'validate_time': time.time()})

    if n_partitions == 1:
        redis_client.set(object_key, blob)

    else:
        for i in range(n_partitions):
            partition_key = _object_partition_key(object_key, i)
            start = i * REDIS_OBJECT_PARTITION_SIZE
            end = (i + 1) * REDIS_OBJECT_PARTITION_SIZE
            redis_client.set(partition_key, blob[start:end])

    del blob


def set_object_file(object_key,
                    object_file,
                    version_id,
                    deserialize,
                    cache_level=LEVEL_1_IN_MEMORY):
    """Insert object into cache.

    Object is first deserialized and inserted into in-memory cache (1st level).
    If `cache_level` is specified as redis (2nd level), a redis connection will
    be established and content of `object_file` will be saved into redis.

    :param object_key: Key to associate the object in cache.
    :param object_file: File-like object which is the serialization of the original object.
    :param version_id: Id used to distinguish different versions of the object.
    :param deserialize: Function that used to deserialize `object_file`.
    :param cache_level: Defaults to `LEVEL_1_IN_MEMORY`.

    :return: Object that deserialized from `object_file`.
    :raises CacheError: If `cache_level` is invalid.
    :raises CacheError: If `version_id` is None.
    :raises CacheError: If `deserialize` is None.
    """
    if not validate_cache_level(cache_level):
        raise CacheError('Invalid cache_level: {}'.format(cache_level))

    if version_id is None:
        raise CacheError('version_id cannot be None.')

    try:
        object_ = _set_object_file_in_memory(object_key, object_file, version_id, deserialize)
    except (TypeError, IOError) as err:
        raise CacheError('Failed to save object into memory from file.\nFrom error:\n{}'
                         .format(repr(err)))

    if cache_level == LEVEL_2_REDIS:
        redis_client = _connect_to_redis()
        try:
            _set_object_file_in_redis(redis_client, object_key, object_file, version_id)
        except (TypeError, IOError) as err:
            raise CacheError('Failed to save object into Redis from file.\nFrom error:\n{}'
                             .format(repr(err)))

    return object_


def get_object(object_key,
               version_id=None,
               cache_level=LEVEL_1_IN_MEMORY,
               deserialize=None,
               validate=None):
    """Retrieve object from cache.

    It queries cache with key to the object.

    :param object_key: Key to associate the object in cache.
    :param version_id: Id used to distinguish different versions of the object.
    :param cache_level: Defaults to `LEVEL_1_IN_MEMORY`.
    :param deserialize: Function that used to deserialize `object_file`.
    :param validate: Callable validator object used to do object version validation.

    :return: Object that exists in cache. None if not exists.
    :raises CacheError: If `cache_level` is invalid.
    """
    if not validate_cache_level(cache_level):
        raise CacheError('Invalid cache_level: {}'.format(cache_level))

    if cache_level == LEVEL_1_IN_MEMORY:
        return _get_object_in_memory(object_key, version_id=version_id, validate=validate)
    else:
        object_ = _get_object_in_memory(object_key, version_id=version_id, validate=validate)
        if object_ is None:
            redis_client = _connect_to_redis()
            try:
                object_ = _get_object_in_redis(redis_client, deserialize, object_key,
                                               version_id=version_id,
                                               validate=validate)
            except (TypeError, IOError) as err:
                raise CacheError('Failed to get object from Redis.\nFrom error:\n{}'
                                 .format(repr(err)))
        return object_
