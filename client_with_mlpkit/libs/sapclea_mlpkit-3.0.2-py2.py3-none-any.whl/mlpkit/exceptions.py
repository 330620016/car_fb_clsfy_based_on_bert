"""mlpkit.exceptions"""

import json

from requests.models import Response


class Error(Exception):
    """MLPKit base exception."""

    pass


class CacheError(Error):
    """Cache domain exception."""

    pass


class ModelError(Error):
    """Model domain exception."""

    pass


class ServiceBrokerError(Error):
    """Service Broker domain exception."""

    pass


class MlpHTTPError(Error):
    """Base exception related to HTTP exceptions in mlpkit client"""

    error_detail = {
        "error": {
            "code": 'InternalServerError',
            "message": "Some error occurred, pleasea try again later.",
            "status": 500
        }}

    def __init__(self, e, *args, **kwargs):
        if isinstance(e, dict):
            self.error_detail.update(e)
        elif hasattr(e, "text") and hasattr(e, "status_code"):  # duck typing for requests.models.Response
            try:
                self.error_detail["error"]["code"] = e.status_code
                self.error_detail["error"]["status"] = e.status_code
                self.error_detail.update(json.loads(e.text))
            except:
                self.error_detail["error"]["message"] = e.text
        else:
            self.error_detail["error"]["message"] = str(e)

        try:
            import cf_logging
            self.error_detail["error"]["requestId"] = cf_logging.get_correlation_id()
        except:
            pass

        try:
            from flask.globals import request
            self.error_detail["error"]["target"] = request.path
        except:
            pass
