"""Provides model utility functions."""

import os
import sys
import logging
import tempfile
import shutil
import time
import requests
import threading
from mlpkit import \
    cache, \
    ModelError

from mlpkit.constants import \
    MLP_MODEL_VALID_DURATION, \
    MLP_MODEL_API_BASE_URL, \
    HEADER_X_CORRELATION_ID

from urllib.parse import urljoin

from mlpkit.exceptions import MlpHTTPError

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))


def _get_correlation_id():
    try:
        import cf_logging
        correlation_id = cf_logging.get_correlation_id()
        return (correlation_id if correlation_id
                                  != cf_logging.EMPTY_VALUE else None)
    except:
        return None


def _create_model_key(namespace, model_name):  # pragma: no cover
    return str(namespace) + ' ' + str(model_name)


class ModelRepoClient(object):
    """This class provides client methods to access ML Foundation Model Repo APIs."""

    _model_file_download_tasks = dict()
    _model_file_download_lock = threading.Lock()

    def _request_header(self):
        header = {'authorization': self.access_token}

        correlation_id = _get_correlation_id()
        if correlation_id:
            header[HEADER_X_CORRELATION_ID] = correlation_id

        return header

    def __init__(self, access_token):
        """
        Creates a ModelRepoClient as client to ML Foundation Model Repo APIs.

        :param: access_token: Token used to access MLP model APIs.
        """

        assert access_token.startswith('Bearer ')
        self.access_token = access_token
        self.model_api_base_url = os.environ[MLP_MODEL_API_BASE_URL]

    def get_latest_model_version(self,
                                 model_name,
                                 namespace=None):
        """
        Get meta-data of latest version of model.

        :param model_name: Model Name
        :param namespace: Namespace

        :return: Meta-data of latest version of model.
        :raises ModelError: If no model is available.
        :raises MlpHTTPError: If call failed.
        """

        latest_model_list = self.get_model_versions(model_name,
                                                    namespace=namespace, query_string={'latest': 'true'})

        LOG.info("Latest model list :" + str(latest_model_list))

        if latest_model_list:
            version = latest_model_list['versions'][0]
            LOG.info("For model name %s , latest version fetched %s ", model_name, str(version))
            return version
        else:
            raise ModelError('Model with name {0} is not found'.format(model_name))

    def _get_latest_model_version_id(self,
                                     model_name,
                                     namespace=None):
        """
        Get latest version id of model.

        :param model_name: Model Name
        :param namespace: Namespace

        :return: Latest version id of model.
        :raises ModelError: If no model is available.
        :raises MlpHTTPError: If call failed.
        """

        latest_version = self.get_latest_model_version(model_name, namespace)
        latest_version_id = latest_version['version']
        return latest_version_id

    def get_model_versions(
            self,
            model_name,
            namespace=None,
            query_string=None,
    ):

        """
        Get all versions of model.

        :param model_name: Model Name
        :param namespace: Namespace

        :return: All versions of model in given namespace.
        :raises MlpHTTPError: If call failed.
        """

        if namespace:
            if query_string:
                query_string['namespace'] = namespace
            else:
                query_string = {'namespace': namespace}

        url_param = {'modelName': model_name}
        url = urljoin(self.model_api_base_url,
                      '/api/v2/models/{modelName}/versions'.format(**url_param))
        resp = requests.get(url, params=query_string,
                            headers=self._request_header())
        if resp.status_code == 200:
            return resp.json()
        else:
            raise MlpHTTPError(resp)

    def get_model_file(
            self,
            model_name,
            model_version=None,
            namespace=None,
    ):
        """
        Get current latest model file or model file based on `model_version`.

        :param model_name: Model Name.
        :param model_version: Model Version, If None, it will retrieve latest model file.
        :param namespace: Namespace

        :return: File-like object of the downloaded model file.
        :raises MlpHTTPError: If call failed.
        """
        if model_version is None:
            model_version = self._get_latest_model_version_id(model_name, namespace);

        url_param = {'modelName': model_name, 'version': model_version}
        url = urljoin(self.model_api_base_url,
                      '/api/v2/models/{modelName}/versions/{version}/format:raw'.format(**url_param))
        querystring = ({'namespace': namespace} if namespace else None)

        resp = requests.get(url, params=querystring, stream=True,
                            headers=self._request_header())
        if resp.status_code == 200:
            with tempfile.NamedTemporaryFile(delete=False) as temp_f:
                shutil.copyfileobj(resp.raw, temp_f)
                return temp_f
        else:
            raise MlpHTTPError(resp)

    def get_cached_model_file(
            self,
            model_name,
            model_version=None,
            namespace=None,
            cache_level=cache.LEVEL_1_IN_MEMORY,
            deserialize=None,
    ):
        """
        Get latest model  or model  based on `model_version`. Cache is enabled.

        :param model_name: Model Name.
        :param model_version: Model Version, If None, it will retrieve latest model file.
        :param namespace: Namespace.
        :param cache_level: Defaults to `LEVEL_1_IN_MEMORY`.
        :param deserialize: Function that used to deserialize model file.

        :return: Model object.
        :raises HTTPError: If model retrieval from MLP model APIs was not successful.
        """
        if model_version is None:
            model_version = self._get_latest_model_version_id(model_name, namespace);

        model_key = _create_model_key(namespace=namespace,
                                      model_name=model_name)
        try:
            self._model_file_download_lock.acquire()
            event = self._model_file_download_tasks.get(model_key, None)
            if isinstance(event, threading.Event):
                self._model_file_download_lock.release()
                event.wait()
            else:
                self._model_file_download_tasks[model_key] = \
                    threading.Event()
                self._model_file_download_lock.release()

            validator = ModelVersionValidator(model_version)

            LOG.info('Retrieving model from cache...')
            model = cache.get_object(model_key,
                                     version_id=model_version, cache_level=cache_level,
                                     deserialize=deserialize, validate=validator)
            if model is not None:
                return model

            LOG.info('Model file not in cache, retrieving model file from model api...')

            model_file = self.get_model_file(model_name=model_name,
                                             namespace=namespace,
                                             model_version=model_version)
            LOG.info('Model file retrieved. De-serializing and caching model file...'
                     )
            deserialized_model = cache.set_object_file(model_key,
                                                       model_file, version_id=model_version,
                                                       deserialize=deserialize, cache_level=cache_level)
            os.remove(model_file.name)
            return deserialized_model
        finally:
            with self._model_file_download_lock:
                event = self._model_file_download_tasks.get(model_key,
                                                            None)
                if isinstance(event, threading.Event):
                    event.set()
                    self._model_file_download_tasks.pop(model_key, None)


class ModelVersionValidator(object):
    """Callable object which is passed to cache to perform validation on cached model objects."""

    def __init__(self, version_id, *args, **kwargs):
        self.version_id = version_id
        self.args = args
        self.kwargs = kwargs
        self.model_valid_duration = max(0, int(os.getenv(MLP_MODEL_VALID_DURATION, '3600')))

    def __call__(self, cached_version_id, cached_validate_time):
        valid = False
        validate_time = cached_validate_time
        curr_timestamp = time.time()
        if curr_timestamp - cached_validate_time > self.model_valid_duration:
            # cached version of this model needs validation
            valid = cached_version_id == self.version_id
        return valid, validate_time
