"""Provides model utility functions."""
# pylint: disable=E0401, E0611
import os
import sys
import logging
import tempfile
import shutil
import time
import threading
from urllib.parse import urljoin
import requests
from mlpkit import (
    cache,
    ModelError,
    MLP_MODEL_VALID_DURATION,
    MLP_MODEL_API_BASE_URL,
    HEADER_X_CORRELATION_ID
)

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))


def _get_correlation_id():
    try:
        import cf_logging
        correlation_id = cf_logging.get_correlation_id()
        return correlation_id if correlation_id != cf_logging.EMPTY_VALUE else None
    except:
        return None


def _create_model_key(namespace, model_name):  # pragma: no cover
    return str(namespace) + ' ' + str(model_name)


class ModelAccessor(object):
    """
    This class provides client methods to access legacy MLP model APIs.
    Please use mlpkit.model_utils.ModelRepoClient to access new ML Foundation Model APIs.
    """

    _model_file_download_tasks = dict()
    _model_file_download_lock = threading.Lock()

    def _request_header(self):
        header = {
            'authorization': self.access_token
        }

        correlation_id = _get_correlation_id()
        if correlation_id:
            header[HEADER_X_CORRELATION_ID] = correlation_id

        return header

    def __init__(self, access_token):
        """
        Creates a ModelAccessor as client to MLP model APIs.

        :param: access_token: Token used to access MLP model APIs.
        """
        assert access_token.startswith('Bearer ')
        self.access_token = access_token
        self.model_api_base_url = os.environ[MLP_MODEL_API_BASE_URL]

    def set_active_model(self, customer, training, version_id):
        """
        Activate the selected version for a model.

        :param customer: Customer ID.
        :param training: Training ID.
        :param version_id: Version ID.

        :return: Active `version_id` if call succeeded.
        :raises HTTPError: If call failed.
        """
        urlparam = {'customer': customer, 'training': training}
        url = urljoin(self.model_api_base_url,
                      '/customers/{customer}/trainings/{training}/models/setActiveModel'
                      .format(**urlparam))
        querystring = {'id': version_id}
        resp = requests.post(url, params=querystring, headers=self._request_header())
        if resp.status_code == 200:
            r_json = resp.json()
            return str(r_json['id'])
        else:
            resp.raise_for_status()

    def get_active_model_version_id(self, customer, training):
        """
        Get current active model's version ID.

        :param customer: Customer ID.
        :param training: Training ID.

        :return: Active `version_id` if call succeeded and active model is available.
        :raises ModelError: If no active model is available.
        :raises HTTPError: If call failed.
        """
        urlparam = {'customer': customer, 'training': training}
        url = urljoin(self.model_api_base_url,
                      '/customers/{customer}/trainings/{training}/models'
                      .format(**urlparam))
        querystring = {'status': 'ACTIVE'}
        resp = requests.get(url, params=querystring, headers=self._request_header())
        if resp.status_code == 200:
            active_model_list = resp.json()
            if active_model_list:
                return str(active_model_list[0]['id'])
            else:
                raise ModelError('No active model is available.')
        else:
            resp.raise_for_status()

    def get_model_file(self, customer, training, version_id=None):
        """
        Get current active model file or model file based on `version_id`.

        :param customer: Customer ID.
        :param training: Training ID.
        :param version_id: Version ID. If None, it will retrieve active model file.

        :return: File-like object of the downloaded model file.
        :raises HTTPError: If call failed.
        """
        if version_id is None:
            urlparam = {'customer': customer, 'training': training}
            url = urljoin(self.model_api_base_url,
                          '/customers/{customer}/trainings/{training}/models/getActiveModel'
                          .format(**urlparam))
        else:
            urlparam = {'customer': customer, 'training': training, 'id': version_id}
            url = urljoin(self.model_api_base_url,
                          '/customers/{customer}/trainings/{training}/models/{id}/file'
                          .format(**urlparam))

        resp = requests.get(url, stream=True, headers=self._request_header())
        if resp.status_code == 200:
            with tempfile.NamedTemporaryFile(delete=False) as temp_f:
                shutil.copyfileobj(resp.raw, temp_f)

            return temp_f
        else:
            resp.raise_for_status()

    def get_model(self, customer, training,
                  version_id=None,
                  cache_level=cache.LEVEL_1_IN_MEMORY,
                  deserialize=None):
        """
        Get current active model object or model object based on `version_id`. Cache is enabled.

        :param customer: Customer ID.
        :param training: Training ID.
        :param version_id: Version ID. If None, it will retrieve active model.
        :param cache_level: Defaults to `LEVEL_1_IN_MEMORY`.
        :param deserialize: Function that used to deserialize model file.

        :return: Model object.
        :raises HTTPError: If model retrieval from MLP model APIs was not successful.
        """
        model_key = _create_model_key(customer, training)
        try:
            self._model_file_download_lock.acquire()
            event = self._model_file_download_tasks.get(model_key, None)
            if isinstance(event, threading.Event):
                self._model_file_download_lock.release()
                event.wait()
            else:
                self._model_file_download_tasks[model_key] = threading.Event()
                self._model_file_download_lock.release()

            validator = ModelValidator(self.get_active_model_version_id, customer, training)
            LOG.info('Retrieving model from cache...')
            model = cache.get_object(model_key,
                                     version_id=version_id,
                                     cache_level=cache_level,
                                     deserialize=deserialize,
                                     validate=validator)
            if model is None:
                LOG.info('Model not in cache, retrieving model file from model api...')
                active_version_id = validator.active_version_id
                if active_version_id is None:
                    # validator did NOT retrieve active_version_id in get_object()
                    # means no knowledge of current active_version_id
                    active_version_id = '?'
                    model_file = self.get_model_file(customer, training)
                else:
                    # validator did retrieve active_version_id in get_object()
                    # means having knowledge of current active_version_id
                    model_file = self.get_model_file(customer, training, active_version_id)

                LOG.info('Model file retrieved. Deserializing and caching model file...')
                deserialized_model = cache.set_object_file(model_key,
                                                           model_file,
                                                           version_id=active_version_id,
                                                           deserialize=deserialize,
                                                           cache_level=cache_level)
                os.remove(model_file.name)
                return deserialized_model
            else:
                return model
        finally:
            with self._model_file_download_lock:
                event = self._model_file_download_tasks.get(model_key, None)
                if isinstance(event, threading.Event):
                    event.set()
                    self._model_file_download_tasks.pop(model_key, None)


class ModelValidator(object):
    """Callable object which is passed to cache to perform validation on cached model objects."""

    def __init__(self, version_id_retriever, *args, **kwargs):
        self.version_id_retriever = version_id_retriever
        self.args = args
        self.kwargs = kwargs
        self.model_valid_duration = max(0, int(os.getenv(MLP_MODEL_VALID_DURATION, '3600')))
        self.__active_version_id = None

    def __call__(self, cached_version_id, cached_validate_time):
        valid = True
        validate_time = cached_validate_time
        curr_timestamp = time.time()
        if curr_timestamp - cached_validate_time > self.model_valid_duration:
            # cached version of this model needs validation
            if self.__active_version_id is None:
                self.__active_version_id = self.version_id_retriever(*self.args, **self.kwargs)
                validate_time = time.time()
            valid = cached_version_id == self.__active_version_id
        return valid, validate_time

    @property
    def active_version_id(self):
        """
        Initially None. If `retriever` is used, it will be updated accordingly.
        """
        return self.__active_version_id
