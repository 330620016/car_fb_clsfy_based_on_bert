"""Provides utility functions to interact with Tensorflow Serving model container."""
# pylint: disable=E0401, E0611
import os
import sys
import logging
from urllib.parse import urljoin
import requests
from mlpkit import (
    ServiceBrokerError,
)

from mlpkit.constants import \
    HEADER_X_CORRELATION_ID, \
    MLP_DEPLOYMENT_API_BASE_URL

from mlpkit.exceptions import MlpHTTPError
from tfs_client.client import TFClient, DefaultMonitor, DefaultTimeit

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))


def _get_correlation_id():
    try:
        import cf_logging
        correlation_id = cf_logging.get_correlation_id()
        return correlation_id if correlation_id != cf_logging.EMPTY_VALUE else None
    except:
        return None


class ModelQuerier(object):
    """
    For querying TFS model container via gRPC protocol
    """

    def __init__(self, model_name=None, namespace=None, model_version=None, timeout=10.0,
                 metric_monitor=DefaultMonitor()):
        self.model_name = model_name
        self.model_version = model_version
        self.namespace = namespace
        self.timeout = timeout
        self.model_container_host_lookup = ModelContainerHostLookUp()
        self.metric_monitor = metric_monitor
        if hasattr(self.metric_monitor, 'get_timeit') and callable(getattr(self.metric_monitor, 'get_timeit')):
            pass
        else:
            self.metric_monitor.get_timeit = DefaultTimeit

    def _get_model_container_lookup_info(self, access_token):
        # for dev and test only.
        host = os.getenv('MLP_MODEL_CONTAINER_HOST')
        if host:
            port = os.environ['MLP_MODEL_CONTAINER_PORT']
            root_cert = os.getenv('MLP_MODEL_CONTAINER_ROOT_CERT')
            return ModelContainerLookUpInfo(lookup_info={'host': host, 'port': int(port)}, root_cert=root_cert)

        return self.model_container_host_lookup(access_token=access_token,
                                                namespace=self.namespace,
                                                model_name=self.model_name,
                                                model_version=self.model_version)

    def _get_monitoring_tags(self):
        return {'model_name': self.model_name, 'namespace': self.namespace, 'model_version': self.model_version}

    def predict(self, request, access_token=None, correlation_id=None):
        """
        Send prediction request.

        :param request: A gRPC request object ready to be send over gRPC channel.
        :param access_token: valid access token
        :param correlation_id: Optional correlation id for tracking request.
        :return: prediction results.
        """
        monitoring_tags = self._get_monitoring_tags()
        with self.metric_monitor.get_timeit(func_name='mc_host_lookup', tags=monitoring_tags):
            mc_lookup_info = self._get_model_container_lookup_info(access_token=access_token)

        with self.metric_monitor.get_timeit(func_name='grpc_channel_establishment', tags=monitoring_tags):
            cert = mc_lookup_info.root_cert.encode() if mc_lookup_info.root_cert else None
            tfc = TFClient(mc_lookup_info.mc_host, mc_lookup_info.mc_port,
                           True if cert else False, cert, access_token, metric_monitor=self.metric_monitor)

        with self.metric_monitor.get_timeit(func_name='mc_query', tags=monitoring_tags):
            if mc_lookup_info.model_placeholder:
                model_name = mc_lookup_info.model_placeholder
                request.model_spec.name = model_name
                LOG.info('Using model placeholder name %s', model_name)

            predict_result = tfc.execute(request, correlation_id, self.timeout)
            return predict_result

    def make_prediction(self, inputs, access_token=None, signature_name=None,
                        correlation_id=None, timeout=10.0, convert_to_dict=False):
        '''
        Build, execute, and format request.

        :param inputs: dictionary of inputs.
        :param access_token: valid access token
        :param signature_name: name of the signature (endpoint) in the model to query.
        :param correlation_id: correlation id for the particular request, used for server loging.
        :param timeout: max value to wait for the response in seconds.
        :param convert_to_dict: flag to specify formatting of the response for python.
        :return: prediction results.
        '''

        monitoring_tags = self._get_monitoring_tags()
        with self.metric_monitor.get_timeit(func_name='mc_host_lookup', tags=monitoring_tags):
            mc_lookup_info = self._get_model_container_lookup_info(access_token=access_token)

        with self.metric_monitor.get_timeit(func_name='grpc_channel_establishment', tags=monitoring_tags):
            cert = mc_lookup_info.root_cert
            tfc = TFClient(mc_lookup_info.mc_host, mc_lookup_info.mc_port,
                           True if cert else False, cert, access_token, metric_monitor=self.metric_monitor)

        with self.metric_monitor.get_timeit(func_name='mc_query', tags=monitoring_tags):
            model_name = self.model_name
            if mc_lookup_info.model_placeholder:
                model_name = mc_lookup_info.model_placeholder
                LOG.info('Using model placeholder name %s', model_name)

            predict_result = tfc.make_prediction(inputs, model_name, self.model_version,
                                                 signature_name, correlation_id, timeout,
                                                 convert_to_dict)

            return predict_result


class ModelContainerHostLookUp(object):
    """
    Callable object that retrieves and caches service broker info.
    """

    def __init__(self):
        self._cache = {}

    def __call__(self, access_token, namespace=None, model_name=None, model_version=None):
        assert access_token.startswith('Bearer ')
        cache_key = self._get_existing_cache_key(namespace=namespace,
                                                 model_name=model_name,
                                                 model_version=model_version)
        if cache_key:
            LOG.info('Returning Service Broker lookup info, which was found in cache: %s',
                     cache_key)
            return self._cache[cache_key]

        service_broker_url = os.environ[MLP_DEPLOYMENT_API_BASE_URL]
        url = urljoin(service_broker_url, '/api/v2/deployments')
        request_header = {
            'Authorization': access_token
        }

        correlation_id = _get_correlation_id()
        if correlation_id:
            request_header[HEADER_X_CORRELATION_ID] = correlation_id

        LOG.info('Querying service broker lookup API @ %s', url)
        params = {'modelName': model_name, 'state': 'SUCCEEDED'}
        if namespace:
            params['namespace'] = namespace

        if model_version:
            params['modelVersion'] = model_version

        resp = requests.get(url, params=params, headers=request_header)

        if int(resp.status_code / 100) != 2:
            LOG.error('Fail to query service broker lookup API. Aborting...')
            raise MlpHTTPError(resp)

        try:
            sb_resp = resp.json()
            assert sb_resp.get('deployments')
            root_cert = sb_resp.get('caCrt')

            model_deployment = self._get_model_deployment(sb_resp['deployments'],
                                                          namespace=namespace,
                                                          model_name=model_name,
                                                          model_version=model_version)
            assert model_deployment
            lookup_info = model_deployment['modelContainer']
            model_placeholder = model_deployment.get('placeholderName')
            cache_model_version = model_deployment['modelVersion']
            the_cache_key = self._build_cache_key(namespace=namespace, model_name=model_name,
                                                  model_version=cache_model_version)
            self._cache[the_cache_key] = ModelContainerLookUpInfo(
                lookup_info=lookup_info, model_placeholder=model_placeholder,
                root_cert=root_cert)

            return self._cache[the_cache_key]
        except AssertionError:
            LOG.error(
                'Unable to find ready model-container with model name: %s and model version: %s, Response:  %s\n',
                model_name, model_version, resp.text
            )
            raise ServiceBrokerError(
                'Unable to find ready model-container with model name: {} and model version: {}.'.format(
                    model_name, model_version
                )
            )
        except KeyError as err:
            LOG.error('Failed to parse Service Broker lookup response: %s\nError type: %s',
                      resp.text, repr(err))
            raise ServiceBrokerError('Failed to parse Service Broker lookup response.')

    def _get_existing_cache_key(self, namespace=None, model_name=None, model_version=None):
        cache_key = self._build_cache_key(namespace=namespace,
                                          model_name=model_name, model_version=model_version)
        return cache_key if self.has_info(cache_key) else None

    @staticmethod
    def _build_cache_key(model_name, namespace, model_version):
        return str(model_name) + ' ' + str(namespace) + ' ' + str(model_version)

    @staticmethod
    def _get_model_deployment(deployments,
                               namespace=None, model_name=None, model_version=None):
        matching_deployment = None
        latest_version = 0
        for deployment in deployments:
            if (not namespace or namespace == deployment['namespace']) and \
                    (model_name == deployment['modelName']):
                if model_version and model_version == deployment['modelVersion']:
                    matching_deployment = deployment
                curr_version = int(deployment['modelVersion'])
                if not model_version and latest_version < curr_version:
                    matching_deployment = deployment
                    latest_version = curr_version

        return matching_deployment

    def clear(self):
        """
        Clear cached service broker info.
        """
        self._cache.clear()

    def has_info(self, cache_key):
        """
        Check if service broker info has been cached.

        :param cache_key:
        :return: True if info is cached.
        """
        return cache_key in self._cache


class ModelContainerLookUpInfo(object):
    def __init__(self, lookup_info, model_placeholder=None, root_cert=None):
        self.mc_host = lookup_info['host'] if lookup_info and lookup_info.get('host') else None
        self.mc_port = int(lookup_info['port']) if lookup_info and lookup_info.get('port') else None
        self.model_placeholder = model_placeholder
        self.root_cert = root_cert
