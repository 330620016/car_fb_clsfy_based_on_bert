"""Provides VCAP SERVICES utility functions."""
import os
import sys
import logging
import json
from .constants import (
    VCAP_SERVICES,
    MLP_FOUNDATION_SERVICE_NAME,
    MLP_FOUNDATION_SERVICE_INSTANCE_NAME,
)

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))


def get_model_api_base_url():
    """
    Retrieving model repo API base URL from VCAP_SERVICES.
    :return: model repo API base URL
    """
    service_urls = _get_foundation_service_urls()
    if not service_urls:
        return None

    return service_urls.get('MODEL_REPO_URL')


def get_deployment_api_base_url():
    """
    Retrieving model deployment API base URL from VCAP_SERVICES.
    :return: model deployment API base URL
    """
    service_urls = _get_foundation_service_urls()
    if not service_urls:
        return None

    return service_urls.get('DEPLOYMENT_API_URL')


def _get_foundation_service_urls():
    service_instance_name = os.getenv(MLP_FOUNDATION_SERVICE_INSTANCE_NAME)
    sb_instance_config = _get_foundation_service_instance_config(service_instance_name)

    if not sb_instance_config \
            or not sb_instance_config.get('credentials') \
            or not sb_instance_config['credentials'].get('serviceurls'):
        return None

    return sb_instance_config['credentials']['serviceurls']


def _get_foundation_service_instance_config(service_instance_name):
    service_name = os.getenv(MLP_FOUNDATION_SERVICE_NAME, 'ml-foundation')

    vcap_raw_value = os.getenv(VCAP_SERVICES)
    if not vcap_raw_value:
        return None

    value = json.loads(vcap_raw_value)
    vcap_services = value[0] if type(value) in (tuple, list) else value
    if not vcap_services \
            or not vcap_services.get(service_name):
        return None

    if type(vcap_services[service_name]) in (tuple, list):
        for svc_inst_config in vcap_services[service_name]:
            if svc_inst_config.get('name') and svc_inst_config['name'] == service_instance_name:
                return svc_inst_config
    else:
        return vcap_services[service_name]
