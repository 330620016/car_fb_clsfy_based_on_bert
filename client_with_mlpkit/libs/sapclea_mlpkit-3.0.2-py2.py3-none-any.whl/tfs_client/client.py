import tensorflow as tf
from grpc.beta import implementations
import grpc
from grpc.framework.interfaces.face import face

from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2

import requests
import json
import time as time_perf
import threading
from queue import Queue
import os
from time import time
import logging
import sys

LOG = logging.getLogger(__name__)
LOG.setLevel(logging.INFO)
LOG.addHandler(logging.StreamHandler(stream=sys.stdout))


class ChannelResource(object):
    def __init__(self, key, valid_channel_duration=300):
        self.key = key
        self._channel = None
        self._timestamp = None
        self._valid_channel_duration = valid_channel_duration

    def ensure_channel_setup(self, server, port, ssl=False, credentials=None):
        if self._is_required_to_setup_channel():
            self._set_channel(self.setup_channel(server, port, credentials=credentials, ssl=ssl))
            LOG.info("Channel created " + self.key)

    def unset_channel(self):
        self._channel = None
        self._timestamp = None
        LOG.info("Channel removed " + self.key)

    def get_channel(self):
        return self._channel

    def _set_channel(self, channel):
        self._channel = channel
        self._timestamp = time()

    def _is_required_to_setup_channel(self):
        return not self._channel or (self._timestamp and time() - self._timestamp > self._valid_channel_duration)

    @staticmethod
    def setup_channel(server, port, ssl=False, credentials=None):
        grpc_max_message_size = int(os.getenv('GRPC_MAX_MESSAGE_SIZE', '8388608'))  # default 8MB
        options = [('grpc.max_message_length', grpc_max_message_size),
                   ('grpc.max_send_message_length', grpc_max_message_size),
                   ('grpc.max_receive_message_length', grpc_max_message_size)]
        if ssl is False:
            channel = grpc.insecure_channel(server if port is None else '%s:%d' % (server, port), options=options)
            return implementations.Channel(channel)
        else:
            channel = grpc.secure_channel(server if port is None else '%s:%d' % (server, port), credentials,
                                          options=options)
            return implementations.Channel(channel)


class ChannelResourceConnectionPool(object):
    def __init__(self):
        self._pool_lock = threading.Lock()
        self._channel_pool_dict = {}
        self._pool_queue_max_size = int(os.getenv('CHANNEL_POOL_MAX_SIZE', '5'))
        self._valid_channel_duration = int(os.getenv('CHANNEL_VALID_DURATION', '300'))

    def release_resource(self, resource):
        start_time = time()
        LOG.debug("releasing resource " + resource.key)
        self._channel_pool_dict[resource.key].put(resource)
        LOG.debug("released resource {0:.2f}".format(time() - start_time))

    def acquire_resource(self, server, port, ssl=False, credentials=None):
        start_time = time()
        key = str(server) + ':' + str(port) + '::' + str(ssl)
        LOG.debug("acquiring resource " + key)
        self._ensure_pool_setup_for_key(key)
        resource = self._channel_pool_dict[key].get()
        resource.ensure_channel_setup(server, port, credentials=credentials, ssl=ssl)
        LOG.debug("acquired resource {0:.2f}".format(time() - start_time))
        return resource

    def _ensure_pool_setup_for_key(self, key):
        self._pool_lock.acquire()
        if not self._channel_pool_dict.get(key):
            self._init_pool_for_key(key)
        self._pool_lock.release()

    def _init_pool_for_key(self, key):
        self._channel_pool_dict[key] = Queue(self._pool_queue_max_size)
        for i in range(0, self._pool_queue_max_size):
            self._channel_pool_dict[key].put(ChannelResource(key, valid_channel_duration=self._valid_channel_duration))


_channel_pool = ChannelResourceConnectionPool()


class DefaultTimeit():
    def __init__(self, func_name='monitoring', tags=None):
        self._func_name = func_name
        self._start = None
        self._tags = tags

    def __enter__(self):
        LOG.info('Starting %s', self._func_name)
        self._start = time_perf.perf_counter()

    def __exit__(self, exc_type, exc_val, exc_tb):
        LOG.info('Finished %s; ===> took %.3f sec.', self._func_name, time_perf.perf_counter() - self._start)


class DefaultMonitor(object):
    """A simple metric monitor"""

    def __init__(self):
        pass

    def add_headers(self, headers: list):
        pass

    def get_timeit(self, func_name='monitoring', tags=None, metric_name=None):
        return DefaultTimeit(func_name=func_name, tags=tags)


class TFClient(object):
    """ class for sending a request to tensorflow serving server """

    def __init__(self, server, port, ssl=False, cert=None, token=None, metric_monitor=DefaultMonitor(), **kwargs):
        """Constructor of the class to setup a channel between a server
        and a client. It also creates the stub for the grpc communication.
        Args:
            server: ip address of the tensorflow serving server
            port: port number on tensorflow serving server listens
            ssl: flag to specify ssl connection
            cert: ssl certificate (content str or '.crt' path)
            token: JWT token
        """
        if isinstance(server, str):
            if server:
                self.server = server
            else:
                raise ValueError("the argument 'server' is empty")
        else:
            raise ValueError("the argument 'server' is not a string")

        try:
            self.port = int(port)
        except ValueError as err:
            raise ValueError("the argument 'port' is invalid: {}".format(repr(err)))

        self.metric_monitor = metric_monitor
        self.token = token
        self.ssl = ssl
        if self.ssl is False:
            self.credentials = None
        else:
            try:
                # for backward compatibility
                cert_path = kwargs.get('certificate_path', None)
                if not cert and cert_path:
                    cert = cert_path
                # for backward compatibility
                with open(cert) as crt:
                    self.credentials = grpc.ssl_channel_credentials(root_certificates=crt.read())
            except:
                self.credentials = grpc.ssl_channel_credentials(root_certificates=cert)

    def message_builder(self, inputs, dst):
        """
        A method to format the message which is sent to the stub
        Args:
            inputs: dictionary with:
                - key - string determining the input name
                - value - list with input as the first element and tensorflow type as the second element
                dst: protobuf request message
        Returns:
            filled protobuf request message
        """
        for key in inputs:
            # copy a python element to the TensorProto
            if type(inputs[key][1]) == tf.DType:
                proto = tf.contrib.util.make_tensor_proto(inputs[key][0], dtype=inputs[key][1])
                dst.inputs[key].CopyFrom(proto)
            else:
                raise ValueError("data_type is not a valid tensorflow type")

        return dst

    def execute(self, request, correlation_id, timeout=10.0):
        """
        A method to execute the request to the server
        Args:
            request: protobuf request message
            correlation_id: correlation id for the particular request, used for server loging
            timeout: max value to wait for the response in seconds
        Returns:
            response from the server
        """

        def metadata_transformer(metadata):
            additions = []
            if self.token:
                tk = self.token
                # TODO: we should enforce token format startswith Bearer instead of doing checkings
                if not tk.startswith('Bearer '):
                    tk = 'Bearer {}'.format(tk)
                additions.append(('authorization', tk))
            if correlation_id:
                # TODO: change 'correlation_id' to HEADER_X_CORRELATION_ID (need change on MC server)
                additions.append(('correlation_id', correlation_id))
            # Add additional headers for metrics recording
            if hasattr(self.metric_monitor, 'add_headers') and callable(getattr(self.metric_monitor, 'add_headers')):
                self.metric_monitor.add_headers(headers=additions)
            return tuple(metadata) + tuple(additions)

        # stub = prediction_service_pb2.beta_create_PredictionService_stub(self.channel,
        #                                                                  metadata_transformer=metadata_transformer)
        resource = _channel_pool.acquire_resource(self.server, self.port, ssl=self.ssl, credentials=self.credentials)
        try:
            stub = prediction_service_pb2.beta_create_PredictionService_stub(
                resource.get_channel(), metadata_transformer=metadata_transformer)
            return stub.Predict(request, timeout)
        except:
            resource.unset_channel()
            raise
        finally:
            _channel_pool.release_resource(resource)

    def make_prediction(self, inputs, model_name, version=None,
                        signature_name=None, correlation_id='', timeout=10.0,
                        convert_to_dict=False):
        """
        A method to call functions for building the request and executing it.
        It also formats the response
        Args:
            inputs: dictionary of inputs
            model_name: name of the model in tensorflow serving server to query
            version: version of the model in tensorflow serving server to query
            signature_name: name of the signature (endpoint) in the model to query
            correlation_id: correlation id for the particular request, used for server loging
            timeout: max value to wait for the response in seconds
            convert_to_dict: flag to specify nicer formating of the response for python
        Returns:
            response from the server
        """
        request = predict_pb2.PredictRequest()
        request.model_spec.name = model_name
        if signature_name:
            request.model_spec.signature_name = signature_name
        if version:
            request.model_spec.version.value = int(version)

        self.message_builder(inputs, request)

        try:
            response = self.execute(request, correlation_id, timeout=timeout)
        except face.AbortionError as e:
            return e

        if not convert_to_dict:
            return response

        # convert to friendly python object
        results_dict = {}
        for key in response.outputs:
            tensor_proto = response.outputs[key]
            nd_array = tf.contrib.util.make_ndarray(tensor_proto)
            results_dict[key] = nd_array

        return results_dict

    @staticmethod
    def get_access_token(username, password, auth_url):
        """
        A static method to get access token from auth_url
        Args:
            username
            password
            auth_url: url to authenticate against
        Returns:
            JWT token
        """
        auth_endpoint = "https://" + username + ":" + password + "@" + auth_url
        response = requests.get(auth_endpoint)

        if (response.ok):
            jData = json.loads(response.content)
            if jData["access_token"]:
                return jData["access_token"]

        return None

    @staticmethod
    def generate_access_token(customer, model, privateKey):
        """
        A static method to generate the access token from the private key
        Args:
            customer: customer who can access the desired model
            model: name of the model to access
            private key
        Returns:
            JWT token
        """
        # return jwt.encode({'scope': [customer, model]}, privateKey, algorithm='RS256')
        raise NotImplementedError('PyJWT is not supported.')
